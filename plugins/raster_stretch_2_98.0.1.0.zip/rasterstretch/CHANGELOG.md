# Changelog

## 0.1.0 — 2025-09-27
- Initial release: percentile stretch (2–98), custom bounds, NoData handling, sampled stats/histogram.
